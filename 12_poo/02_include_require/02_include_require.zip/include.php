<?php
// include: faz inclusão de documentos
// include_once: inclui o documento solicitado uma única vez

include 'cabecalho.php';

// include_once 'cabecalho.php';
// include_once 'cabecalho.php';

echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';

// include_once 'rodape.php';
// include_once 'rodape.php';

include 'rodape.php';

?>