<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <!-- CABEÇALHO -->
    <div style='width: 100%; height: 80px; background-color:blue'>
        <div style='font-size: 30px; color:#fff; text-align:center;'>
            AULAS DE PHP
        </div> 
    </div>

  