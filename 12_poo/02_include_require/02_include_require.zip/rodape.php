  <!-- RODAPÉ -->
  <div style='width: 100%; height: 120px; background-color:gray'>
        <div style='font-size: 15px; color:#fff; text-align:center;'>
            <p> Este é um rodapé </p>
            <p> Aulas de PHP </p>
        </div>  
    </div>

</body>

</html>