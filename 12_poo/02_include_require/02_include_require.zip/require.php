<?php
// require: faz inclusão de documentos
// require_once: requisita o documento solicitado uma única vez

// require 'cabecalho.php';
require 'cabecalho.php';

// require_once 'cabecalho.php';
// require_once 'cabecalho.php';

echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';
echo '<br />';

// require_once 'rodape.php';
// require_once 'rodape.php';

// require 'rodape.php';
require 'rodape.php';

?>